lineWidth = 50
print 'This_is_Chapter_5'
puts
print  '#reverse_string_method '

var1 = 'stop'
var2 = 'stressed'
var3 = 'Can you pronounce this sentence backwards?'

puts
puts var1.reverse
puts 
puts var2.reverse
puts
puts var3.reverse
puts
puts var1
puts
puts var2
puts
puts var3
puts

print '#length_string_method '

puts 'What is your full name?'
name = gets.chomp
puts 'Did you know there are ' + name.length.to_s +
     ' characters in your name, ' + name + '?'
     
     
print '#changing_case_string_method'

letters = 'aAbBcCdDeE'
puts letters.upcase
puts letters.downcase
puts letters.swapcase
puts letters.capitalize
puts ' a'.capitalize
puts letters

print '#visual_formatting_string_method'

lineWidth = 50
puts(                'Old Mother Hubbard'.center(lineWidth))
puts(               'Sat in her cupboard'.center(lineWidth))
puts(         'Eating her curds an whey,'.center(lineWidth))
puts(          'When along came a spider'.center(lineWidth))
puts(         'Which sat down beside her'.center(lineWidth))
puts('And scared her poor shoe dog away.'.center(lineWidth))     
     
print 'This_'     