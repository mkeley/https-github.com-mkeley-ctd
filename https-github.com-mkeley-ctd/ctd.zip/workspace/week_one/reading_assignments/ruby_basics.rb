# output an integer

puts 3 

# output the number of seconds in a week

puts 60*(60*24)*7

# output a float

puts 98.999

# output a string

puts 'I like ' + 'Pepperoni Pizza.'


# output concatination of strings

String1 = "Hello"

String2 = "World"

puts String1  + String2

str1 = 'Hello'

str2 = 'World'

puts str1 + str2

puts 'revision'



